// Importa as fotos oficiais do anúncio do Airbnb e gera as versões otimizadas do site.
// USE SOMENTE com autorização do proprietário (Thiago Ramalho) para uso das imagens.
//
// Como usar (precisa do Node.js 18+ instalado):
//   cd ferramentas
//   npm install
//   npm run fotos
//
// Alternativa: coloque suas próprias fotos (JPG/PNG) em ferramentas/originais/
// com os nomes abaixo (ex.: rooftop-mar.jpg) e rode "npm run fotos" — os arquivos
// locais têm prioridade sobre o download.

import sharp from 'sharp';
import { mkdir, readFile, writeFile, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.resolve(here, '../site/images');
const SRC = path.resolve(here, 'originais');
const BASE = 'https://a0.muscache.com/im/pictures/hosting/Hosting-1624825580005779387/original/';

const FOTOS = [
  { nome: 'rooftop-mar', arquivo: '13b30cb1-6318-4eee-ae8a-90766f740593.jpeg' }, // capa: piscina + vista da praia
  { nome: 'studio',      arquivo: '8d3e3497-4a0e-4d90-9eae-33550352a059.jpeg' }, // interior integrado
  { nome: 'quarto',      arquivo: 'c8ba8541-e1e3-4672-9b65-804f4d784d18.jpeg' }, // cama + TV
  { nome: 'lounge',      arquivo: 'c86d47e4-0ab5-4d1c-83e5-88b09faae98f.jpeg' }, // lounge/bar do rooftop
  { nome: 'piscina',     arquivo: 'eb49539c-d036-4f30-bb64-1908cbc4d2a1.jpeg' }, // piscina com coqueiros
];

async function existe(p) { try { await access(p); return true; } catch { return false; } }

async function obter(f) {
  for (const ext of ['jpg', 'jpeg', 'png', 'webp']) {
    const local = path.join(SRC, `${f.nome}.${ext}`);
    if (await existe(local)) { console.log(`• ${f.nome}: usando arquivo local`); return readFile(local); }
  }
  console.log(`• ${f.nome}: baixando do anúncio oficial…`);
  const r = await fetch(BASE + f.arquivo);
  if (!r.ok) throw new Error(`Falha ao baixar ${f.nome} (HTTP ${r.status})`);
  return Buffer.from(await r.arrayBuffer());
}

await mkdir(OUT, { recursive: true });
for (const f of FOTOS) {
  const buf = await obter(f);
  for (const w of [800, 1600]) {
    await sharp(buf).rotate().resize({ width: w, withoutEnlargement: false }).webp({ quality: w === 800 ? 74 : 72, effort: 5 })
      .toFile(path.join(OUT, `${f.nome}-${w}.webp`));
  }
  if (f.nome === 'rooftop-mar') {
    await sharp(buf).rotate().resize(1200, 630, { fit: 'cover', position: 'attention' }).jpeg({ quality: 80, mozjpeg: true })
      .toFile(path.join(OUT, 'og.jpg'));
  }
}
console.log(`\nPronto! Imagens otimizadas em ${OUT}`);
