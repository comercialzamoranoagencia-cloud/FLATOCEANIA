# Flat Oceania | Alta Garden — site oficial

Desenvolvido por **Zamorano Agency**. Site estático (HTML, CSS e JavaScript), pronto para o Netlify.

```
flat-oceania/
├── site/                  ← ESTA é a pasta publicada no Netlify
│   ├── index.html         ← site completo (CSS e JS embutidos)
│   ├── images/            ← fotos otimizadas (WebP) — geradas pela ferramenta abaixo
│   ├── assets/fonts/      ← Cormorant Garamond + Manrope (auto-hospedadas)
│   ├── assets/vendor/     ← GSAP 3.15, ScrollTrigger, Lenis 1.3 (locais)
│   ├── favicon.svg  404.html  robots.txt  sitemap.xml
│   └── _headers           ← cabeçalhos de segurança e cache do Netlify
├── ferramentas/           ← importador de fotos (não é publicado)
└── ARQUITETURA-FASE-2.md  ← plano do sistema de reservas diretas
```

---

## 1. Antes de publicar (checklist)

| Item | Onde ajustar | Situação |
|---|---|---|
| Autorização do proprietário para usar as fotos | — | **Confirmar com Thiago Ramalho** |
| Fotos em `site/images/` | Passo 2 | Pasta vazia: o site mostra um fundo artístico no lugar das fotos |
| Capacidade (3 ou 4 hóspedes) | `maxHospedes` | Usando 3 (limite conservador) |
| WhatsApp autorizado | `whatsapp` | Vazio → botões de WhatsApp ocultos |
| Domínio definitivo | Passo 4 | Usando `flatoceania.netlify.app` como proposta |
| Endereço público para rota | `enderecoPublicoParaRota` | Vazio → botão de rota oculto |
| Revisão dos textos pelo proprietário | `index.html` | Recomendado |

> Nenhuma pendência aparece para o visitante: funções que dependem de informação ainda não confirmada ficam simplesmente ocultas.

---

## 2. Fotos (uma vez, com autorização)

O site usa as 5 fotos do anúncio oficial do Airbnb (vista/piscina, studio, quarto, lounge e piscina com coqueiros).

**Opção A — automática (precisa do Node.js 18+):**

```bash
cd ferramentas
npm install
npm run fotos
```

O script baixa as fotos do anúncio, gera `nome-800.webp` e `nome-1600.webp` em `site/images/` e cria `og.jpg` (imagem de compartilhamento 1200×630).

**Opção B — fotos próprias:** coloque os arquivos em `ferramentas/originais/` com os nomes `rooftop-mar`, `studio`, `quarto`, `lounge`, `piscina` (`.jpg`, `.png` ou `.webp`) e rode `npm run fotos`. Arquivos locais têm prioridade.

**Mais fotos na galeria:** gere `id-800.webp` e `id-1600.webp`, e adicione uma linha na lista `PHOTOS` (no `index.html`, procure por `var PHOTOS`). Categorias: `flat`, `rooftop`, `piscina`, `vista`, `estrutura`, `praia`. Um filtro aparece automaticamente quando a categoria tem 2 ou mais fotos.

---

## 3. Configurações

No `site/index.html`, procure por **`window.FLAT_CONFIG`**:

```js
maxHospedes: 3,          // capacidade máxima (o calendário e o seletor respeitam)
hospedesPadrao: 2,
whatsapp: "",            // ex.: "5583999999999" (DDI + DDD + número, só dígitos)
airbnbComDatas: true,    // envia check_in, check_out e adults ao Airbnb (testado)
enderecoPublicoParaRota: "", // só com autorização; ativa o botão "Traçar rota"
heroVideo: null          // vídeo real e autorizado: { mp4: "images/hero.mp4", poster: "..." }
```

Ao preencher o `whatsapp`, aparecem automaticamente: botão flutuante, "Solicitar reserva direta", opção no resumo da estadia (com a mensagem padrão contendo datas, noites e hóspedes) e o contato no rodapé.

---

## 4. Domínio, SEO e Google

Quando o domínio for definido, substitua `flatoceania.netlify.app` pelo domínio real em:

- `site/index.html` (og:url, og:image e os dados estruturados) e **descomente a linha `canonical`**;
- `site/robots.txt` e `site/sitemap.xml`.

Já implementado: title e meta description, Open Graph, HTML semântico, alt nas imagens, dados estruturados `LodgingBusiness` e `FAQPage` (sem notas, avaliações ou preços inventados), sitemap e robots.

**Google Search Console:** adicione a propriedade do domínio → verifique pelo DNS (ou pela meta tag que o Google fornecer, colada no `<head>`) → envie `https://SEU-DOMINIO/sitemap.xml`. Posicionamento no Google não pode ser garantido.

---

## 5. Visualizar no computador

Abra `site/index.html` no navegador (duplo clique) ou use a extensão *Live Server* do VS Code.

## 6. Publicar no Netlify (somente com autorização)

1. Acesse **app.netlify.com** → *Add new site* → *Deploy manually*.
2. Arraste a pasta **`site`** (não a pasta `flat-oceania`).
3. Em *Domain management*, configure o domínio.

O Netlify já entrega os arquivos compactados (gzip/brotli) e aplica os cabeçalhos do `_headers` (segurança + cache).

---

## 7. Como funciona a consulta de reservas

1. O visitante escolhe check-in, check-out (calendário próprio em português, sem datas passadas, check-out sempre depois do check-in) e hóspedes (limitado à capacidade).
2. O site calcula as noites e mostra o resumo da estadia.
3. O visitante segue para o **Airbnb com as datas preenchidas** ou, se configurado, envia uma **solicitação** pelo WhatsApp.

O site **não** mostra datas como disponíveis, **não** confirma reservas e **não** cobra nada: disponibilidade e valores são confirmados no Airbnb ou pelo anfitrião.

---

## 8. Testes realizados

- **Desktop (1440 px), tablet (820 px) e celular (390 px)** em Chrome automatizado: sem erros de JavaScript no console e sem rolagem horizontal.
- **53 verificações automáticas** (desktop e celular): validação sem datas, bloqueio de datas passadas, check-out igual/anterior ao check-in, cálculo de noites, limite de hóspedes, sincronização das duas barras de consulta, resumo, link do Airbnb com parâmetros, galeria (abrir, setas, teclado, Esc, filtros), FAQ, abas, menu mobile (abrir, Esc, navegação), calendário por teclado e modo de movimento reduzido.
- **Parâmetros do Airbnb** testados no navegador real: o anúncio abriu com as datas e os hóspedes preenchidos.
- **WhatsApp** testado com número simulado: a mensagem gerada segue o modelo definido.
- **Lighthouse** (com compressão, como no Netlify, e cópias provisórias em baixa resolução das fotos): celular — Desempenho 92, Acessibilidade 100, Boas práticas 100, SEO 100; desktop — 100 em todas.

**Não testado:** aparelhos físicos (iPhone/Android), o site com as fotos definitivas (rode o Lighthouse novamente depois de importá-las) e a publicação no Netlify.

---

## 9. Próxima etapa

O plano do sistema completo de reservas diretas (painel, calendário, iCal, pagamentos) está em `ARQUITETURA-FASE-2.md`.
