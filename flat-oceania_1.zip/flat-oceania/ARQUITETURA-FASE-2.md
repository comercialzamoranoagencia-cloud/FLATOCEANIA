# Flat Oceania — Fase 2: sistema de reservas diretas

Plano de evolução do site atual (estático) para um sistema completo, sem reescrever o front-end: a consulta de datas existente passa a conversar com uma API em vez de apenas encaminhar para o Airbnb.

## Stack

| Camada | Ferramenta | Papel |
|---|---|---|
| Hospedagem | Netlify | Site + painel `/admin` + funções serverless |
| Banco e login | Supabase (Postgres + Auth) | Dados, autenticação do administrador (com MFA) e regras de acesso (RLS) |
| Operações protegidas | Netlify Functions | Cotação, criação de reservas, pagamentos, iCal |
| E-mail | Resend ou Brevo | Confirmações e avisos |
| Pagamento | Provedor autorizado (ex.: Mercado Pago, Asaas, Stripe) | Pix e cartão, com webhook assinado |

**Regras de segurança:** a chave `service_role` do Supabase e as chaves do provedor de pagamento ficam **apenas** nas variáveis de ambiente das funções. O navegador nunca recebe dados de outros hóspedes. Nada de painel em `localStorage`.

## Banco de dados (Postgres)

- `reservas`: origem (`direto`, `airbnb`, `bloqueio`), check-in, check-out, hóspedes, status (`solicitada`, `aguardando_pagamento`, `confirmada`, `cancelada`), valores, taxa de limpeza, expiração do pré-bloqueio.
- `hospedes`: nome, e-mail, telefone (o mínimo necessário, conforme a LGPD).
- `tarifas`: diária padrão, fins de semana, feriados e temporadas, mínimo de noites.
- `bloqueios`: datas bloqueadas manualmente pelo administrador.
- `pagamentos`: provedor, status, valor, identificador externo.
- `eventos_ical`: datas ocupadas importadas do Airbnb.
- `configuracoes`: capacidade, taxa de limpeza, regras da casa.

**Proteção contra reserva dupla:** restrição `EXCLUDE USING gist (daterange(check_in, check_out, '[)') WITH &&)` nas reservas ativas. Mesmo com duas solicitações simultâneas, o banco recusa a segunda.

## Funções serverless

| Função | Acesso | O que faz |
|---|---|---|
| `disponibilidade` | público | Devolve apenas os intervalos ocupados (sem dados pessoais) |
| `cotacao` | público | Calcula o valor no servidor (diárias + taxa de limpeza) |
| `solicitar-reserva` | público | Revalida as datas (inclusive re-sincronizando o iCal), cria um pré-bloqueio de 15–30 min e gera a cobrança |
| `webhook-pagamento` | provedor | Verifica a assinatura, confirma a reserva e envia o e-mail |
| `calendario.ics` | público | Exporta as reservas diretas para o Airbnb bloquear essas datas |
| `sincronizar-ical` | agendada | Importa o calendário do Airbnb periodicamente |

**Sobre o iCal:** a sincronização tem atraso e não garante disponibilidade em tempo real. Por isso nenhuma reserva direta é confirmada sem uma nova verificação no momento da solicitação. Nos primeiros meses, o ideal é a confirmação manual pelo administrador.

## Painel administrativo (`/admin`)

Login (Supabase Auth + MFA) → calendário de ocupação (Airbnb + diretas + bloqueios), bloqueio manual de datas, cadastro e edição de reservas, gestão de hóspedes, tarifas (fim de semana, feriados, temporadas) e taxa de limpeza, histórico, status de pagamento, cancelamentos e indicadores (taxa de ocupação, diária média, faturamento mensal, origem das reservas).

## Entregas sugeridas

1. **2a:** painel, calendário, bloqueios, iCal (ida e volta) e solicitações com confirmação manual.
2. **2b:** tarifas e cotação automática no site.
3. **2c:** pagamento online (Pix/cartão) e e-mails automáticos — somente após contrato com o provedor e autorização do proprietário.
4. **2d:** indicadores de ocupação e faturamento.

**Política comercial:** as reservas diretas são para quem chega pelo site, Instagram ou indicação. Hóspedes captados no Airbnb continuam no Airbnb.
